import { createContext, ReactNode, useContext, useCallback } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { insertUserSchema, User as SelectUser, InsertUser } from "@shared/schema";
import { getQueryFn, apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { SiweMessage } from "siwe";

// Add ethereum to window type
declare global {
  interface Window {
    ethereum: any;
  }
}

type AuthContextType = {
  user: SelectUser | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<SelectUser, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<SelectUser, Error, InsertUser>;
  connectWallet: () => Promise<void>;
  walletLoginMutation: UseMutationResult<SelectUser, Error, { message: string; signature: string }>;
};

type LoginData = Pick<InsertUser, "username" | "password">;

export const AuthContext = createContext<AuthContextType | null>(null);
export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<SelectUser | null>({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  // Define mutations
  const walletLoginMutation = useMutation({
    mutationFn: async ({ message, signature }: { message: string; signature: string }) => {
      console.log("Submitting to /api/wallet/verify", { message, signature });
      try {
        const res = await apiRequest("POST", "/api/wallet/verify", { message, signature });
        const data = await res.json();
        console.log("Wallet verification response:", data);
        return data;
      } catch (err) {
        console.error("Error during wallet verification:", err);
        throw err;
      }
    },
    onSuccess: (user: SelectUser) => {
      console.log("Wallet login successful:", user);
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Web3 login successful",
        description: `Welcome ${user.wallet_address ? `${user.wallet_address.substring(0, 6)}...${user.wallet_address.substring(user.wallet_address.length - 4)}` : user.username}!`,
      });
    },
    onError: (error: any) => {
      console.error("Wallet login error details:", error);
      toast({
        title: "Web3 login failed",
        description: error.message || "Could not verify wallet signature",
        variant: "destructive",
      });
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      const res = await apiRequest("POST", "/api/login", credentials);
      return await res.json();
    },
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Login successful",
        description: `Welcome back, ${user.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message || "Invalid username or password",
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (credentials: InsertUser) => {
      const res = await apiRequest("POST", "/api/register", credentials);
      return await res.json();
    },
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Registration successful",
        description: `Welcome, ${user.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message || "Username may already be taken",
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      // Clear all user-specific cached data
      queryClient.removeQueries({ queryKey: ["/api/creator-applications/user"] });
      queryClient.removeQueries({ queryKey: ["/api/airdrops"] });
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Web3 wallet authentication - simplified version
  const connectWallet = useCallback(async () => {
    try {
      // Check if browser has Web3 provider
      if (typeof window.ethereum === 'undefined') {
        toast({
          title: "Web3 not available",
          description: "Please install MetaMask or another Web3 wallet to continue.",
          variant: "destructive",
        });
        return;
      }

      console.log("Requesting accounts...");
      
      // Request wallet connection
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      const address = accounts[0];
      
      if (!address) {
        throw new Error("No accounts found. Make sure your wallet is unlocked.");
      }
      
      console.log("Connected address:", address);
      
      toast({
        title: "Wallet connected",
        description: `Connected to ${address.substring(0, 6)}...${address.substring(address.length - 4)}`,
      });
      
      // Generate an authentication message
      const timestamp = Date.now();
      const message = `Sign this message to authenticate with Crypto Airdrop Hub: ${timestamp}`;
      
      console.log("Requesting signature for message:", message);
      
      // Get user signature
      const signature = await window.ethereum.request({
        method: 'personal_sign',
        params: [message, address]
      });
      
      console.log("Signature received:", signature);
      
      // Verify signature on server
      try {
        const result = await fetch("/api/wallet/verify", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ address, signature }),
          credentials: "include"
        });
        
        if (!result.ok) {
          const errorText = await result.text();
          throw new Error(errorText || "Wallet verification failed");
        }
        
        const userData = await result.json();
        console.log("Wallet login successful:", userData);
        
        // Manually update the query data
        queryClient.setQueryData(["/api/user"], userData);
        
        toast({
          title: "Web3 login successful",
          description: `Welcome ${userData.wallet_address ? `${userData.wallet_address.substring(0, 6)}...${userData.wallet_address.substring(userData.wallet_address.length - 4)}` : userData.username}!`,
        });
      } catch (error) {
        console.error("Error during wallet verification:", error);
        toast({
          title: "Wallet verification failed",
          description: error instanceof Error ? error.message : "Server could not verify your wallet",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Wallet connection error:", error);
      toast({
        title: "Wallet connection failed",
        description: error instanceof Error ? error.message : "Failed to connect wallet",
        variant: "destructive",
      });
    }
  }, [toast]);

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
        connectWallet,
        walletLoginMutation
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
