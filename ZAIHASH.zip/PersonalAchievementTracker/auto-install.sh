#!/bin/bash

# Auto Installation Script for Crypto Airdrop Platform
# Run this on your Ubuntu/Debian VPS as root

set -e

echo "🚀 Starting Auto Installation..."
echo "================================"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Please run as root: sudo ./auto-install.sh"
    exit 1
fi

echo "📦 Step 1: Installing system packages..."
apt update && apt upgrade -y
apt install -y curl wget

echo "📦 Step 2: Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

echo "📦 Step 3: Installing PostgreSQL..."
apt install -y postgresql postgresql-contrib

echo "📦 Step 4: Installing Nginx..."
apt install -y nginx

echo "📦 Step 5: Installing PM2..."
npm install -g pm2

echo "🗃️ Step 6: Setting up database..."
systemctl start postgresql
systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "CREATE DATABASE crypto_airdrop;" 2>/dev/null || echo "Database already exists"
sudo -u postgres psql -c "CREATE USER crypto_user WITH PASSWORD 'crypto_pass_123';" 2>/dev/null || echo "User already exists"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE crypto_airdrop TO crypto_user;"
sudo -u postgres psql -c "ALTER USER crypto_user CREATEDB;"

echo "📁 Step 7: Setting up application directory..."
mkdir -p /var/www/crypto-airdrop
cp -r . /var/www/crypto-airdrop/
cd /var/www/crypto-airdrop

echo "⚙️ Step 8: Creating environment file..."
cat > .env << 'EOF'
DATABASE_URL=postgresql://crypto_user:crypto_pass_123@localhost:5432/crypto_airdrop
PGHOST=localhost
PGPORT=5432
PGUSER=crypto_user
PGPASSWORD=crypto_pass_123
PGDATABASE=crypto_airdrop
NODE_ENV=production
PORT=5000
SESSION_SECRET=crypto-airdrop-secret-key-change-in-production
EOF

echo "📦 Step 9: Installing app dependencies..."
npm install

echo "🗃️ Step 10: Setting up database tables..."
export $(cat .env | xargs)
PGPASSWORD=crypto_pass_123 psql -h localhost -U crypto_user -d crypto_airdrop << 'SQL'
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password TEXT,
    wallet_address TEXT UNIQUE,
    nonce TEXT,
    is_admin BOOLEAN DEFAULT false NOT NULL,
    is_creator BOOLEAN DEFAULT false NOT NULL,
    bio TEXT,
    saved_tasks JSONB DEFAULT '[]'::jsonb,
    completed_tasks JSONB DEFAULT '[]'::jsonb,
    twitter_handle TEXT,
    discord_handle TEXT,
    telegram_handle TEXT,
    profile_image TEXT,
    created_at TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT now() NOT NULL,
    updated_at TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS airdrops (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    tags JSONB DEFAULT '[]'::jsonb,
    link TEXT,
    status TEXT DEFAULT 'active' NOT NULL,
    views INTEGER DEFAULT 0 NOT NULL,
    category_id INTEGER REFERENCES categories(id),
    created_at TIMESTAMP DEFAULT now() NOT NULL,
    updated_at TIMESTAMP DEFAULT now() NOT NULL,
    posted_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS newsletters (
    id SERIAL PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    subscribed_at TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS announcements (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    type TEXT DEFAULT 'info' NOT NULL,
    is_active BOOLEAN DEFAULT true NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    link TEXT,
    link_text TEXT,
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT now() NOT NULL,
    updated_at TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS creator_applications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    status TEXT DEFAULT 'pending' NOT NULL,
    reason TEXT,
    payment_tx_hash TEXT,
    payment_amount TEXT,
    payment_currency TEXT,
    reviewed_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT now() NOT NULL,
    updated_at TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS site_settings (
    id SERIAL PRIMARY KEY,
    site_name TEXT DEFAULT 'Crypto Airdrop Task Hub' NOT NULL,
    site_description TEXT DEFAULT 'Discover and track crypto airdrops, tasks, and rewards.' NOT NULL,
    logo_url TEXT,
    banner_url TEXT,
    twitter_link TEXT,
    discord_link TEXT,
    telegram_link TEXT,
    creator_fee_currency TEXT DEFAULT 'USDT' NOT NULL,
    creator_fee_amount TEXT DEFAULT '10' NOT NULL,
    creator_payment_address TEXT,
    creator_payment_network TEXT DEFAULT 'Ethereum Mainnet',
    created_at TIMESTAMP DEFAULT now() NOT NULL,
    updated_at TIMESTAMP DEFAULT now() NOT NULL
);

-- Insert sample data
INSERT INTO users (username, password, is_admin, is_creator) VALUES 
('admin', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewBkuEdPzfqGULUi', true, true),
('demo', '$2b$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', false, false)
ON CONFLICT (username) DO NOTHING;

INSERT INTO categories (name, description) VALUES 
('DeFi', 'Decentralized Finance protocols and airdrops'),
('Gaming', 'Blockchain gaming and NFT-related airdrops'),
('Mining', 'Airdrops related to mining and staking'),
('Exchange', 'Cryptocurrency exchange airdrops'),
('Social', 'Social media and community-based airdrops')
ON CONFLICT (name) DO NOTHING;

INSERT INTO airdrops (title, description, tags, link, category_id, posted_by) VALUES 
('Arbitrum Odyssey Rewards', 'Complete tasks on Arbitrum network to earn rewards and potential airdrop eligibility.', '["arbitrum", "layer2", "defi"]', 'https://arbitrum.io', 1, 'admin'),
('MetaMask Swap Rewards', 'Use MetaMask Swap feature to earn points and potential future rewards.', '["metamask", "swap", "ethereum"]', 'https://metamask.io', 1, 'admin'),
('Polygon zkEVM Testnet', 'Test the new Polygon zkEVM and earn early adopter rewards.', '["polygon", "zkevm", "testnet"]', 'https://polygon.technology', 1, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO site_settings (id, site_name, site_description) VALUES 
(1, 'Crypto Airdrop Task Hub', 'Discover and track crypto airdrops, tasks, and rewards.')
ON CONFLICT (id) DO NOTHING;
SQL

echo "🌐 Step 11: Configuring Nginx..."
cat > /etc/nginx/sites-available/crypto-airdrop << 'EOF'
server {
    listen 80;
    server_name _;
    
    client_max_body_size 10M;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    location /ws {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

# Enable the site
ln -sf /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test and restart Nginx
nginx -t
systemctl restart nginx
systemctl enable nginx

echo "🚀 Step 12: Starting the application..."
# Set proper permissions
chown -R www-data:www-data /var/www/crypto-airdrop
chmod -R 755 /var/www/crypto-airdrop

# Start with PM2
cd /var/www/crypto-airdrop
export $(cat .env | xargs)
pm2 start npm --name "crypto-airdrop" -- start
pm2 save
pm2 startup systemd -u root --hp /root

echo ""
echo "🎉 Installation Complete!"
echo "========================"
echo ""
echo "✅ Your crypto airdrop platform is now running!"
echo ""
echo "🌐 Access your site:"
echo "   http://$(curl -s ifconfig.me 2>/dev/null || echo 'your-server-ip')"
echo "   http://localhost (if accessing locally)"
echo ""
echo "👤 Login credentials:"
echo "   Admin: admin / admin123"
echo "   Demo:  demo / demo123"
echo ""
echo "📊 Management commands:"
echo "   pm2 status                 - Check app status"
echo "   pm2 logs crypto-airdrop    - View app logs"
echo "   pm2 restart crypto-airdrop - Restart app"
echo "   systemctl status nginx     - Check nginx"
echo ""
echo "🔧 Configuration:"
echo "   App folder: /var/www/crypto-airdrop"
echo "   Environment: /var/www/crypto-airdrop/.env"
echo "   Database: crypto_airdrop (crypto_user/crypto_pass_123)"
echo ""
echo "🛠️ If you need to troubleshoot:"
echo "   pm2 logs crypto-airdrop"
echo "   systemctl status postgresql"
echo "   systemctl status nginx"
echo ""